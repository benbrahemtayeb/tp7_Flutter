import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'classes_screen.dart';
import 'config.dart';

class Etudiant {
  final int id;
  final String nom;
  final String prenom;
  final int? codClasse;

  Etudiant(this.id, this.nom, this.prenom, this.codClasse);

  factory Etudiant.fromMap(Map<String, dynamic> m) {
    final classe = m['classe'];
    return Etudiant(
      m['id'],
      m['nom'] ?? '',
      m['prenom'] ?? '',
      classe is Map ? classe['codClass'] : null,
    );
  }
}

class EtudiantsScreen extends StatefulWidget {
  const EtudiantsScreen({super.key});

  @override
  State<EtudiantsScreen> createState() => _EtudiantsScreenState();
}

class _EtudiantsScreenState extends State<EtudiantsScreen> {
  List<Classe> _classes = [];
  Classe? _selected;
  List<Etudiant> _tous = [];
  bool _loading = true;
  String? _error;

  List<Etudiant> get _affiches => _selected == null
      ? []
      : _tous.where((e) => e.codClasse == _selected!.codClass).toList();

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    try {
      final classes = await fetchClasses();
      final etudiants = await _fetchEtudiants();
      if (!mounted) return;
      setState(() {
        _classes = classes;
        _selected = classes.isNotEmpty ? classes.first : null;
        _tous = etudiants;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = e.toString();
        _loading = false;
      });
    }
  }

  Future<List<Etudiant>> _fetchEtudiants() async {
    final res = await http.get(Uri.parse('$baseUrl/etudiants'));
    if (res.statusCode != 200) {
      throw Exception('Failed to load students (HTTP ${res.statusCode})');
    }
    final decoded = jsonDecode(res.body);
    // Accepte un tableau simple ou le format HAL de Spring Data REST
    final List data = decoded is List
        ? decoded
        : (decoded['_embedded']?['etudiants'] ?? []);
    if (data.isNotEmpty && data.first is Map && !(data.first as Map).containsKey('classe')) {
      throw Exception(
          'Le JSON des étudiants ne contient pas le champ "classe". Vérifie @JsonIgnore côté Spring.');
    }
    return data.map((e) => Etudiant.fromMap(e)).toList();
  }

  @override
  Widget build(BuildContext context) {
    final etudiants = _affiches;
    return Scaffold(
      appBar: AppBar(title: const Text('Manage students')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(child: Text('Erreur : $_error'))
              : Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(16),
                      child: Row(
                        children: [
                          const Text('Classe : ',
                              style: TextStyle(fontWeight: FontWeight.bold)),
                          const SizedBox(width: 12),
                          DropdownButton<Classe>(
                            value: _selected,
                            hint: const Text('Code Classe'),
                            items: _classes
                                .map((c) => DropdownMenuItem<Classe>(
                                      value: c,
                                      child: Text(c.nomClass),
                                    ))
                                .toList(),
                            onChanged: (c) {
                              if (c == null) return;
                              setState(() => _selected = c);
                            },
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      child: etudiants.isEmpty
                          ? const Center(child: Text('Aucun étudiant'))
                          : ListView.builder(
                              itemCount: etudiants.length,
                              itemBuilder: (context, i) => ListTile(
                                leading: const Icon(Icons.school),
                                title: Text('${etudiants[i].nom} ${etudiants[i].prenom}'),
                              ),
                            ),
                    ),
                  ],
                ),
    );
  }
}
