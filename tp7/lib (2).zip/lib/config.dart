// Émulateur : 10.0.2.2 | Téléphone physique : IPv4 du PC (ipconfig)
const String baseUrl = "http://192.168.1.53:8081";
